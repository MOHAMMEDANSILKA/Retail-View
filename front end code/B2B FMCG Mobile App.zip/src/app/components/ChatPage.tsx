import { useState } from "react";
import { Search, MoreVertical, Phone, Video, ArrowLeft, Send, Paperclip, Smile } from "lucide-react";

interface Chat {
  id: string;
  name: string;
  lastMessage: string;
  time: string;
  unread: number;
  avatar: string;
  online: boolean;
}

interface Message {
  id: string;
  text: string;
  time: string;
  sent: boolean;
  status: "sent" | "delivered" | "read";
}

const chats: Chat[] = [
  {
    id: "1",
    name: "FreshDairy Co.",
    lastMessage: "We can offer bulk discount on yogurt",
    time: "10:30 AM",
    unread: 2,
    avatar: "FD",
    online: true
  },
  {
    id: "2",
    name: "NutriSnack Inc.",
    lastMessage: "Protein bars shipment ready",
    time: "9:15 AM",
    unread: 0,
    avatar: "NS",
    online: true
  },
  {
    id: "3",
    name: "BevDistribute Ltd.",
    lastMessage: "Thanks for the order!",
    time: "Yesterday",
    unread: 0,
    avatar: "BD",
    online: false
  },
  {
    id: "4",
    name: "EnergyPro Wholesale",
    lastMessage: "Can we schedule a call?",
    time: "Yesterday",
    unread: 1,
    avatar: "EP",
    online: false
  },
  {
    id: "5",
    name: "SnackWorld Traders",
    lastMessage: "New products available",
    time: "Jun 12",
    unread: 0,
    avatar: "SW",
    online: false
  },
];

const mockMessages: Message[] = [
  {
    id: "1",
    text: "Hi, I'm interested in bulk ordering yogurt",
    time: "10:20 AM",
    sent: true,
    status: "read"
  },
  {
    id: "2",
    text: "Hello! Great to hear from you. What quantity are you looking for?",
    time: "10:22 AM",
    sent: false,
    status: "read"
  },
  {
    id: "3",
    text: "Around 500 cases per month",
    time: "10:25 AM",
    sent: true,
    status: "read"
  },
  {
    id: "4",
    text: "We can offer bulk discount on yogurt",
    time: "10:30 AM",
    sent: false,
    status: "delivered"
  },
  {
    id: "5",
    text: "15% off for orders over 400 cases",
    time: "10:30 AM",
    sent: false,
    status: "delivered"
  },
];

export function ChatPage() {
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [messageInput, setMessageInput] = useState("");
  const [messages, setMessages] = useState<Message[]>(mockMessages);

  const filteredChats = chats.filter((chat) =>
    chat.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentChat = chats.find((chat) => chat.id === selectedChat);

  const sendMessage = () => {
    if (messageInput.trim()) {
      const newMessage: Message = {
        id: String(messages.length + 1),
        text: messageInput,
        time: new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }),
        sent: true,
        status: "sent"
      };
      setMessages([...messages, newMessage]);
      setMessageInput("");
    }
  };

  if (selectedChat && currentChat) {
    return (
      <div className="h-full flex flex-col bg-gray-50">
        {/* Chat Header */}
        <div className="bg-[#075E54] px-4 py-3 flex items-center gap-3">
          <button
            onClick={() => setSelectedChat(null)}
            className="text-white hover:bg-white/10 rounded-full p-1 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center font-semibold text-[#075E54] flex-shrink-0">
              {currentChat.avatar}
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="font-semibold text-white truncate">{currentChat.name}</h2>
              <p className="text-xs text-green-100">
                {currentChat.online ? "Online" : "Last seen yesterday"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-white">
            <button className="hover:bg-white/10 rounded-full p-1.5 transition-colors">
              <Video className="w-5 h-5" />
            </button>
            <button className="hover:bg-white/10 rounded-full p-1.5 transition-colors">
              <Phone className="w-5 h-5" />
            </button>
            <button className="hover:bg-white/10 rounded-full p-1.5 transition-colors">
              <MoreVertical className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Messages Area */}
        <div 
          className="flex-1 overflow-y-auto px-4 py-4"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d1d5db' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            backgroundColor: "#e5ddd5"
          }}
        >
          <div className="space-y-2 max-w-2xl mx-auto">
            {messages.map((message, index) => (
              <div
                key={message.id}
                className={`flex ${message.sent ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[75%] rounded-lg px-3 py-2 ${
                    message.sent
                      ? "bg-[#dcf8c6] text-gray-900"
                      : "bg-white text-gray-900"
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                  <div className="flex items-center justify-end gap-1 mt-1">
                    <span className="text-xs text-gray-500">{message.time}</span>
                    {message.sent && (
                      <span className="text-gray-500">
                        {message.status === "read" && "✓✓"}
                        {message.status === "delivered" && "✓✓"}
                        {message.status === "sent" && "✓"}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Message Input */}
        <div className="bg-gray-100 px-3 py-2 flex items-center gap-2">
          <button className="text-gray-600 hover:text-gray-900 p-2">
            <Smile className="w-6 h-6" />
          </button>
          <button className="text-gray-600 hover:text-gray-900 p-2">
            <Paperclip className="w-6 h-6" />
          </button>
          <input
            type="text"
            placeholder="Type a message"
            value={messageInput}
            onChange={(e) => setMessageInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && sendMessage()}
            className="flex-1 bg-white rounded-full px-4 py-2 text-sm focus:outline-none"
          />
          <button
            onClick={sendMessage}
            className="bg-[#075E54] text-white p-2.5 rounded-full hover:bg-[#064e46] transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-[#075E54] px-4 py-4">
        <h1 className="text-xl font-semibold text-white mb-3">Chats</h1>
        
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search chats..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white/10 border-0 rounded-lg text-sm text-white placeholder-gray-200 focus:outline-none focus:ring-2 focus:ring-white/30"
          />
        </div>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto bg-white">
        {filteredChats.map((chat) => (
          <div
            key={chat.id}
            onClick={() => setSelectedChat(chat.id)}
            className="flex items-center gap-3 px-4 py-3 border-b border-gray-100 hover:bg-gray-50 active:bg-gray-100 cursor-pointer transition-colors"
          >
            <div className="relative">
              <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center font-semibold text-gray-600">
                {chat.avatar}
              </div>
              {chat.online && (
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-semibold text-gray-900 truncate">{chat.name}</h3>
                <span className="text-xs text-gray-500 flex-shrink-0 ml-2">{chat.time}</span>
              </div>
              <p className="text-sm text-gray-600 truncate">{chat.lastMessage}</p>
            </div>

            {chat.unread > 0 && (
              <div className="w-5 h-5 bg-[#25D366] rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-xs text-white font-semibold">{chat.unread}</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
