import { useState } from "react";
import { MapPin, Search, Building2, Navigation } from "lucide-react";

interface Company {
  id: string;
  name: string;
  type: "manufacturer" | "distributor";
  address: string;
  city: string;
  phone: string;
  distance: string;
}

const companies: Company[] = [
  {
    id: "1",
    name: "FreshDairy Co.",
    type: "manufacturer",
    address: "1234 Dairy Lane, Industrial Park",
    city: "Chicago, IL",
    phone: "+1 (312) 555-0123",
    distance: "2.3 km"
  },
  {
    id: "2",
    name: "NutriSnack Inc.",
    type: "manufacturer",
    address: "567 Nutrition Blvd, Suite 100",
    city: "Los Angeles, CA",
    phone: "+1 (213) 555-0456",
    distance: "5.7 km"
  },
  {
    id: "3",
    name: "BevDistribute Ltd.",
    type: "distributor",
    address: "890 Distribution Dr, Warehouse 5",
    city: "New York, NY",
    phone: "+1 (212) 555-0789",
    distance: "1.8 km"
  },
  {
    id: "4",
    name: "EnergyPro Wholesale",
    type: "distributor",
    address: "321 Wholesale Way",
    city: "Miami, FL",
    phone: "+1 (305) 555-0321",
    distance: "4.2 km"
  },
  {
    id: "5",
    name: "SnackWorld Traders",
    type: "distributor",
    address: "654 Trade Center Rd",
    city: "Houston, TX",
    phone: "+1 (713) 555-0654",
    distance: "3.5 km"
  },
  {
    id: "6",
    name: "Fresh Juice Co.",
    type: "manufacturer",
    address: "987 Fresh Ave, Building C",
    city: "San Francisco, CA",
    phone: "+1 (415) 555-0987",
    distance: "6.1 km"
  },
];

export function LocationsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "manufacturer" | "distributor">("all");

  const filteredCompanies = companies.filter((company) => {
    const matchesSearch = 
      company.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      company.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      company.address.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = filter === "all" || company.type === filter;
    
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white px-4 py-4 border-b border-gray-200">
        <h1 className="text-xl font-semibold text-gray-900 mb-3">Locations</h1>
        
        {/* Search Bar */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search companies, cities..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-gray-100 border-0 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Filter Chips */}
        <div className="flex gap-2">
          <button
            onClick={() => setFilter("all")}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
              filter === "all"
                ? "bg-blue-600 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter("manufacturer")}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
              filter === "manufacturer"
                ? "bg-blue-600 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            Manufacturers
          </button>
          <button
            onClick={() => setFilter("distributor")}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
              filter === "distributor"
                ? "bg-blue-600 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            Distributors
          </button>
        </div>
      </div>

      {/* Map Placeholder */}
      <div className="bg-gray-200 h-48 flex items-center justify-center border-b border-gray-300">
        <div className="text-center">
          <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-2" />
          <p className="text-sm text-gray-600">Map View</p>
          <p className="text-xs text-gray-500">Interactive map would appear here</p>
        </div>
      </div>

      {/* Company List */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        <div className="space-y-3 pb-4">
          {filteredCompanies.map((company) => (
            <div
              key={company.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-4"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3 flex-1">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Building2 className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 mb-1">{company.name}</h3>
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${
                      company.type === "manufacturer"
                        ? "bg-green-100 text-green-700"
                        : "bg-purple-100 text-purple-700"
                    }`}>
                      {company.type === "manufacturer" ? "Manufacturer" : "Distributor"}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-gray-600 flex-shrink-0">
                  <Navigation className="w-4 h-4" />
                  <span className="text-sm font-medium">{company.distance}</span>
                </div>
              </div>

              <div className="space-y-2 mb-3">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                  <div className="text-sm text-gray-600">
                    <p>{company.address}</p>
                    <p>{company.city}</p>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
                  Get Directions
                </button>
                <button className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
                  Call {company.phone.slice(-8)}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
