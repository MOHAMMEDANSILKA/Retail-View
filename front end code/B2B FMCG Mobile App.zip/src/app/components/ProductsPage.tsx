import { useState } from "react";
import { Search, Heart, Phone } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface Product {
  id: string;
  name: string;
  category: string;
  price: string;
  seller: string;
  image: string;
  moq: string;
}

const products: Product[] = [
  {
    id: "1",
    name: "Greek Yogurt Multi-Pack",
    category: "Dairy",
    price: "$45.00/case",
    seller: "FreshDairy Co.",
    image: "https://images.unsplash.com/photo-1604095853918-1a1823a63dd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b2d1cnQlMjBwYWNrYWdpbmclMjBwcm9kdWN0fGVufDF8fHx8MTc4MTQ0ODc0MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    moq: "50 cases"
  },
  {
    id: "2",
    name: "Protein Energy Bars (24pk)",
    category: "Snacks",
    price: "$32.00/box",
    seller: "NutriSnack Inc.",
    image: "https://images.unsplash.com/photo-1621057621391-7ed446a24b41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm90ZWluJTIwYmFyJTIwcGFja2FnaW5nfGVufDF8fHx8MTc4MTQ0ODc0MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    moq: "100 boxes"
  },
  {
    id: "3",
    name: "Premium Soft Drinks (12oz)",
    category: "Beverages",
    price: "$28.00/case",
    seller: "BevDistribute Ltd.",
    image: "https://images.unsplash.com/photo-1545334894-9c7a7ccefaf8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2Z0JTIwZHJpbmslMjBib3R0bGUlMjBwcm9kdWN0fGVufDF8fHx8MTc4MTQ0ODc0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    moq: "200 cases"
  },
  {
    id: "4",
    name: "Energy Drink Cans (250ml)",
    category: "Beverages",
    price: "$38.00/case",
    seller: "EnergyPro Wholesale",
    image: "https://images.unsplash.com/photo-1560689189-65b6ed6228e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmVyZ3klMjBkcmluayUyMGNhbnxlbnwxfHx8fDE3ODE0NDg3NDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    moq: "150 cases"
  },
  {
    id: "5",
    name: "Gourmet Snack Mix",
    category: "Snacks",
    price: "$24.00/box",
    seller: "SnackWorld Traders",
    image: "https://images.unsplash.com/photo-1688217170693-e821c6e18d72?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbmFjayUyMGZvb2QlMjBwYWNrYWdpbmd8ZW58MXx8fHwxNzgxNDQ4NzQyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    moq: "80 boxes"
  },
  {
    id: "6",
    name: "Cold-Pressed Juice (16oz)",
    category: "Beverages",
    price: "$52.00/case",
    seller: "Fresh Juice Co.",
    image: "https://images.unsplash.com/photo-1640213505284-21352ee0d76b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqdWljZSUyMGJvdHRsZSUyMHByb2R1Y3R8ZW58MXx8fHwxNzgxNDQ4NzQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    moq: "75 cases"
  },
];

export function ProductsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [savedProducts, setSavedProducts] = useState<Set<string>>(new Set());

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.seller.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleSave = (productId: string) => {
    setSavedProducts((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(productId)) {
        newSet.delete(productId);
      } else {
        newSet.add(productId);
      }
      return newSet;
    });
  };

  const handleContact = (seller: string) => {
    alert(`Contacting ${seller}...`);
  };

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white px-4 py-4 border-b border-gray-200">
        <h1 className="text-xl font-semibold text-gray-900 mb-3">B2B Products</h1>
        
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search products, categories, sellers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-gray-100 border-0 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Product List */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        <div className="space-y-4 pb-4">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden"
            >
              {/* Product Image */}
              <div className="relative h-48 bg-gray-100">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2 bg-white px-2 py-1 rounded-md text-xs font-medium text-gray-700">
                  {product.category}
                </div>
              </div>

              {/* Product Details */}
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-1">{product.name}</h3>
                <p className="text-sm text-gray-600 mb-1">{product.seller}</p>
                <p className="text-xs text-gray-500 mb-3">MOQ: {product.moq}</p>
                
                {/* Price */}
                <div className="mb-4">
                  <span className="text-2xl font-bold text-blue-600">{product.price}</span>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={() => toggleSave(product.id)}
                    className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border transition-colors ${
                      savedProducts.has(product.id)
                        ? "bg-blue-50 border-blue-200 text-blue-600"
                        : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    <Heart
                      className={`w-4 h-4 ${
                        savedProducts.has(product.id) ? "fill-blue-600" : ""
                      }`}
                    />
                    <span className="text-sm font-medium">
                      {savedProducts.has(product.id) ? "Saved" : "Save"}
                    </span>
                  </button>
                  
                  <button
                    onClick={() => handleContact(product.seller)}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                    <span className="text-sm font-medium">Contact Seller</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
