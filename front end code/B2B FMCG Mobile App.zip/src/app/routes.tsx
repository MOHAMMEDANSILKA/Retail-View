import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { ProductsPage } from "./components/ProductsPage";
import { LocationsPage } from "./components/LocationsPage";
import { ChatPage } from "./components/ChatPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: ProductsPage },
      { path: "locations", Component: LocationsPage },
      { path: "chat", Component: ChatPage },
    ],
  },
]);
